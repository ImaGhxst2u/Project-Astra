// Downloads the real Ultraviolet + bare-mux files into /uv and /baremux (no npm needed, Node 18+).
// Run from this folder:  node get-files.js
// bare-mux is pinned to 2.1.6 on purpose: it must match the version compiled into uv.bundle.js.
const fs=require('fs');
const UV='https://cdn.jsdelivr.net/npm/@titaniumnetwork-dev/ultraviolet@3.2/dist/';
const BM='https://cdn.jsdelivr.net/npm/@mercuryworkshop/bare-mux@2.1.6/dist/';
const jobs=[...['uv.bundle.js','uv.client.js','uv.handler.js','uv.sw.js'].map(f=>[UV+f,'uv/'+f]),...['index.js','worker.js'].map(f=>[BM+f,'baremux/'+f])];
(async()=>{let bad=0;for(const [u,p] of jobs){fs.mkdirSync(p.split('/')[0],{recursive:true});
 try{const r=await fetch(u);if(!r.ok)throw new Error('HTTP '+r.status);fs.writeFileSync(p,Buffer.from(await r.arrayBuffer()));console.log('OK  ',p)}
 catch(e){bad=1;console.error('FAIL',p,String(e.message||e),'\n     tried',u)}}
console.log(bad?'\nSome files failed. Try setup.js (npm) instead, or download them by hand.':'\nAll 6 files downloaded. Your own uv/uv.config.js and sw.js are kept. Deploy over HTTPS, then open the Dev Panel: every file should say "found".')})();
