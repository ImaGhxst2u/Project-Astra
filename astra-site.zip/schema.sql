-- Run in Supabase SQL editor. Enable Auth > Anonymous sign-ins (for optional "guest" logins).
create table profiles(id uuid primary key references auth.users, username text unique not null, role text not null default 'user', bio text, avatar text, display_name text, name_color text, name_font text, banner text);
create table messages(id bigserial primary key, from_id uuid, from_name text, to_id uuid, room text not null default 'general' check(room in ('general','staff')), body text not null check(length(body)<500), created_at timestamptz default now());
create table bans(user_id uuid primary key, until timestamptz, permanent bool default false, by uuid);
create table ban_requests(id bigserial primary key, target uuid, reason text, by uuid, created_at timestamptz default now());
create function rank(r text) returns int language sql immutable as $$ select case r when 'owner' then 5 when 'coowner' then 4 when 'headadmin' then 3 when 'admin' then 2 when 'mod' then 1 when 'trial' then 0 else -1 end $$;
create function myrank() returns int language sql stable security definer as $$ select rank(role) from profiles where id=auth.uid() $$;
create function muted(u uuid) returns bool language sql stable security definer as $$ select exists(select 1 from bans where user_id=u and (permanent or until>now())) $$;
alter table profiles enable row level security; alter table messages enable row level security; alter table bans enable row level security; alter table ban_requests enable row level security;
create policy p_read on profiles for select using(true);
create policy p_self on profiles for insert with check(id=auth.uid() and role='user');
-- Public chat is visible to all; DMs only to the two people + staff (users are told staff may review chats).
create policy m_read on messages for select using((room='general' and (to_id is null or to_id=auth.uid() or from_id=auth.uid())) or myrank()>=0);
create policy m_send on messages for insert with check(from_id=auth.uid() and not muted(auth.uid()) and (room='general' or myrank()>=0));
create policy b_read on bans for select using(user_id=auth.uid() or myrank()>=0);
create policy r_read on ban_requests for select using(myrank()>=0);
create function set_role(target uuid, new_role text) returns void language plpgsql security definer as $$
begin if myrank()<3 or (myrank()<5 and (rank(new_role)>=myrank() or rank((select role from profiles where id=target))>=myrank())) then raise exception 'not allowed'; end if;
update profiles set role=new_role where id=target; end $$;
create function punish(target uuid, perm bool, mins int) returns void language plpgsql security definer as $$
begin if myrank()<0 or rank((select role from profiles where id=target))>=myrank() then raise exception 'not allowed'; end if;
if perm and myrank()<2 then raise exception 'only Admins and above can perm ban; Mods/Trial Mods must request'; end if;
if not perm and mins>43200 then raise exception 'max timeout is 1 month'; end if;
insert into bans values(target, now()+make_interval(mins=>coalesce(mins,0)), perm, auth.uid()) on conflict(user_id) do update set until=excluded.until, permanent=excluded.permanent, by=excluded.by; end $$;
create function request_ban(target uuid, why text) returns void language sql security definer as $$ insert into ban_requests(target,reason,by) select target,why,auth.uid() where myrank()>=0 $$;
-- Make yourself owner after signing up once as ImaGhxst2u:
-- update profiles set role='owner' where username='ImaGhxst2u';

-- Already ran an older schema? Run this instead of re-creating tables:
-- alter table messages add column room text not null default 'general' check(room in ('general','staff'));
-- drop policy m_read on messages; drop policy m_send on messages;
-- then re-run the two 'create policy m_read' / 'm_send' statements above.
-- The Staff Room is enforced here: non-staff can neither read nor insert room='staff' rows.

-- Profiles: users can only change their own bio/avatar through this function (never their role).
create function update_profile(new_bio text, new_avatar text, new_display text, new_color text, new_font text, new_banner text) returns void language sql security definer as $$
  update profiles set bio=left(new_bio,200), avatar=case when length(new_avatar)<60000 then new_avatar end, display_name=left(new_display,24),
   name_color=case when new_color ~ '^#[0-9a-fA-F]{6}$' then new_color end, name_font=case when new_font in ('orbitron','pacifico','cinzel','audiowide','mono') then new_font end,
   banner=case when new_banner ~ '^https?://[^\s"''\\()<>]{1,400}$' then new_banner end where id=auth.uid() $$;
-- Already ran an older schema? alter table profiles add column bio text, add column avatar text; then create the function above.
-- Sign-up/sign-in uses username@astra.local, so in Supabase turn OFF Auth > Providers > Email > 'Confirm email'. Anonymous sign-ins are no longer needed.
-- Already have the profile columns? alter table profiles add column display_name text, add column name_color text, add column name_font text, add column banner text; then replace update_profile (drop function update_profile(text,text) first).
