importScripts('/uv/uv.bundle.js','/uv/uv.config.js','/uv/uv.sw.js');
const sw = new UVServiceWorker();
self.addEventListener('fetch', e => e.respondWith((async () => {
  await sw.loadConfig?.();
  if (sw.route(e)) return sw.fetch(e);   // ONLY /uv/service/ requests
  return fetch(e.request);
})()));
