// Run once after `npm i`: copies the real Ultraviolet + bare-mux files into /uv and /baremux.
// Usage: npm i @titaniumnetwork-dev/ultraviolet@~3.2.0 @mercuryworkshop/bare-mux@2.1.6 && node setup.js
const fs=require('fs'),path=require('path');
const {uvPath}=require('@titaniumnetwork-dev/ultraviolet');
const {baremuxPath}=require('@mercuryworkshop/bare-mux/node');
const cp=(src,dst,skip=[])=>{fs.mkdirSync(dst,{recursive:true});for(const f of fs.readdirSync(src)){const p=path.join(src,f);if(skip.includes(f)||fs.statSync(p).isDirectory())continue;fs.copyFileSync(p,path.join(dst,f))}};
cp(uvPath,'uv',['uv.config.js','sw.js']);   // keep OUR uv.config.js and root sw.js
cp(baremuxPath,'baremux');
let bad=0;for(const f of ['uv/uv.bundle.js','uv/uv.client.js','uv/uv.handler.js','uv/uv.sw.js','uv/uv.config.js','baremux/worker.js','baremux/index.js'])if(!fs.existsSync(f)){console.error('MISSING',f);bad=1}
console.log(bad?'Setup incomplete - see MISSING above.':'Done. Deploy this folder over HTTPS. Open the Dev Panel to confirm every file shows "found".');
