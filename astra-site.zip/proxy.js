// Wisp servers below are BORROWED public endpoints, not ours. Keep all five so it survives if one dies.
const WISPS=['wss://kristenblackburnvolleyballcamps.com/socket/','wss://southpadreislandkiteboarding.com/socket/','wss://fern.best/wisp/','wss://wisp.mercurywork.shop/','wss://anura.pro/wisp/'];
// epoxy 2.1.28 on purpose: 3.x breaks with bare-mux 2.1.6 ("headers is not iterable").
const EPOXY='https://cdn.jsdelivr.net/npm/@mercuryworkshop/epoxy-transport@2.1.28/dist/index.mjs';
const load=s=>new Promise((r,j)=>{const e=document.createElement('script');e.src=s;e.onload=r;e.onerror=j;document.head.append(e)});
const probe=u=>new Promise((res,rej)=>{const w=new WebSocket(u),t=setTimeout(()=>{w.close();rej()},4000);w.onopen=()=>{clearTimeout(t);w.close();res(u)};w.onerror=()=>{clearTimeout(t);rej()}});
window.AstraProxy={ready:null,
 init(){return this.ready??=(async()=>{
  await load('/uv/uv.bundle.js');await load('/uv/uv.config.js');await load('/baremux/index.js');
  const reg=await navigator.serviceWorker.register('/sw.js',{scope:'/'});await navigator.serviceWorker.ready;
  const wisp=await Promise.any(WISPS.map(probe));
  this.wisp=wisp;await new BareMux.BareMuxConnection('/baremux/worker.js').setTransport(EPOXY,[{wisp}]);
 })()},
 encode:u=>__uv$config.prefix+__uv$config.encodeUrl(u),
 decode:p=>{try{return __uv$config.decodeUrl(p.split(__uv$config.prefix)[1])}catch{return p}},
 async test(){return Promise.all(WISPS.map(async u=>{const t=performance.now();try{await probe(u);return[u,Math.round(performance.now()-t)]}catch{return[u,null]}}))},
 url(q,tpl){q=q.trim();if(/^https?:\/\//.test(q))return q;if(/^[\w-]+(\.[\w-]+)+(\/.*)?$/.test(q))return'https://'+q;return(tpl||'https://duckduckgo.com/?q=%s').replace('%s',encodeURIComponent(q))}};
